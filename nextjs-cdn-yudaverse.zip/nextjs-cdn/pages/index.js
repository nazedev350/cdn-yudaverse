import Head from "next/head";
import { useEffect, useRef, useState } from "react";

export default function Home() {
  const [configOk, setConfigOk] = useState(true);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMsg, setStatusMsg] = useState("");
  const [toast, setToast] = useState({ show: false, msg: "", error: false });
  const [hasBigFile, setHasBigFile] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const audioRef = useRef(null);
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [seekVal, setSeekVal] = useState(0);
  const [volume, setVolume] = useState(80);
  const [timeNow, setTimeNow] = useState("0:00");
  const [timeTotal, setTimeTotal] = useState("0:00");

  useEffect(() => {
    const cfg = getConfig();
    setConfigOk(!!(cfg.token && cfg.username && cfg.repo));
  }, []);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume / 100;
  }, [volume]);

  function getConfig() {
    if (typeof window === "undefined") return {};
    return {
      token: localStorage.getItem("yuda_gh_token") || "",
      username: localStorage.getItem("yuda_gh_username") || "",
      repo: localStorage.getItem("yuda_gh_repo") || "",
      branch: localStorage.getItem("yuda_gh_branch") || "main",
      folder: localStorage.getItem("yuda_gh_folder") || "",
    };
  }

  function showToast(msg, error = false) {
    setToast({ show: true, msg, error });
    setTimeout(() => setToast({ show: false, msg: "", error: false }), 3000);
  }

  function getTypeLabel(mime) {
    if (!mime) return "raw";
    if (mime.startsWith("image")) return "image";
    if (mime.startsWith("video")) return "video";
    if (mime.startsWith("audio")) return "audio";
    return "raw";
  }

  function getTypeIcon(t) {
    return t === "image" ? "🖼" : t === "video" ? "🎬" : t === "audio" ? "🎵" : "📄";
  }

  function formatSize(b) {
    if (!b) return "—";
    if (b < 1024) return b + " B";
    if (b < 1048576) return (b / 1024).toFixed(1) + " KB";
    return (b / 1048576).toFixed(2) + " MB";
  }

  function fmtTime(s) {
    if (isNaN(s) || !isFinite(s)) return "0:00";
    return Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0");
  }

  function generateFilename(originalName) {
    const ext = originalName.includes(".")
      ? "." + originalName.split(".").pop().toLowerCase()
      : "";
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    let rand = "";
    for (let i = 0; i < 8; i++) rand += chars[Math.floor(Math.random() * chars.length)];
    return rand + ext;
  }

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(",")[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function uploadToGitHub(file) {
    const cfg = getConfig();
    if (!cfg.token || !cfg.username || !cfg.repo)
      throw new Error("Konfigurasi GitHub belum lengkap.");
    const filename = generateFilename(file.name);
    const folder = cfg.folder ? cfg.folder.replace(/^\/|\/$/g, "") + "/" : "";
    const path = folder + filename;
    const apiUrl = `https://api.github.com/repos/${cfg.username}/${cfg.repo}/contents/${path}`;
    const base64 = await fileToBase64(file);
    const res = await fetch(apiUrl, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${cfg.token}`,
        "Content-Type": "application/json",
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
      },
      body: JSON.stringify({
        message: `Upload ${filename} via CDN Yudaverse`,
        content: base64,
        branch: cfg.branch,
      }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    // URL via Vercel (domain sendiri) — itulah tujuan utama
    const vercelUrl = `${window.location.origin}/${folder}${filename}`;
    const rawUrl = `https://raw.githubusercontent.com/${cfg.username}/${cfg.repo}/${cfg.branch}/${path}`;
    return { filename, path, vercelUrl, rawUrl, size: file.size };
  }

  async function handleFiles(fileList) {
    const cfg = getConfig();
    if (!cfg.token || !cfg.username || !cfg.repo) {
      showToast("⚠ Konfigurasi GitHub belum diisi!", true);
      setConfigOk(false);
      return;
    }
    setHasBigFile(Array.from(fileList).some((f) => f.size > 50 * 1024 * 1024));
    setUploading(true);
    setProgress(0);
    let uploaded = 0;
    const newFiles = [];
    for (const file of fileList) {
      setStatusMsg(`Mengupload ${file.name}... (${uploaded + 1}/${fileList.length})`);
      try {
        const data = await uploadToGitHub(file);
        newFiles.push({
          id: Date.now() + "" + Math.random(),
          name: file.name.replace(/\.[^.]+$/, ""),
          format: file.name.split(".").pop(),
          rtype: getTypeLabel(file.type),
          size: data.size,
          vercelUrl: data.vercelUrl,
          rawUrl: data.rawUrl,
          filename: data.filename,
        });
        uploaded++;
        setProgress(Math.round((uploaded / fileList.length) * 100));
      } catch (e) {
        setStatusMsg("⚠ Gagal: " + e.message);
        showToast("⚠ " + e.message, true);
        await new Promise((r) => setTimeout(r, 2000));
      }
    }
    setUploadedFiles((prev) => [...newFiles, ...prev]);
    setStatusMsg(`✓ ${uploaded} file berhasil diupload`);
    showToast(`✓ ${uploaded} file diupload ke GitHub CDN`);
    setTimeout(() => { setUploading(false); setProgress(0); setStatusMsg(""); }, 3000);
  }

  function copyUrl(url) {
    navigator.clipboard?.writeText(url).then(() => showToast("✓ URL disalin!")).catch(() => {
      const ta = document.createElement("textarea");
      ta.value = url;
      ta.style.cssText = "position:fixed;left:-9999px;opacity:0;";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      showToast("✓ URL disalin!");
    });
  }

  function removeFile(id) {
    if (currentTrack?.id === id) closePlayer();
    setUploadedFiles((prev) => prev.filter((f) => f.id !== id));
  }

  function playAudio(file) {
    setCurrentTrack(file);
    if (audioRef.current) {
      audioRef.current.src = file.rawUrl;
      audioRef.current.volume = volume / 100;
      audioRef.current.play().catch((e) => showToast("⚠ " + e.message, true));
    }
    setIsPlaying(true);
  }

  function togglePlay() {
    if (!currentTrack || !audioRef.current) return;
    if (isPlaying) { audioRef.current.pause(); setIsPlaying(false); }
    else { audioRef.current.play(); setIsPlaying(true); }
  }

  function seekTo(val) {
    if (audioRef.current?.duration)
      audioRef.current.currentTime = (val / 100) * audioRef.current.duration;
  }

  function closePlayer() {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.src = ""; }
    setCurrentTrack(null); setIsPlaying(false); setSeekVal(0); setTimeNow("0:00");
  }

  function handleTimeUpdate() {
    const a = audioRef.current;
    if (!a?.duration) return;
    setSeekVal((a.currentTime / a.duration) * 100);
    setTimeNow(fmtTime(a.currentTime));
    setTimeTotal(fmtTime(a.duration));
  }

  const badgeClass = { image: "badge-image", video: "badge-video", audio: "badge-audio", raw: "badge-raw" };

  return (
    <>
      <Head><title>CDN Yudaverse</title></Head>
      <style>{`
        :root{--bg-primary:#050d1a;--bg-secondary:#0a1628;--bg-card:#0d1e35;--bg-input:#091422;--accent:#1e90ff;--accent-bright:#3da8ff;--accent-glow:rgba(30,144,255,0.18);--accent-border:rgba(30,144,255,0.35);--text-primary:#e8f4ff;--text-secondary:#7ba8cc;--text-muted:#4a6f91;--border:rgba(30,144,255,0.15);--border-strong:rgba(30,144,255,0.3);--success:#22d3a0;--danger:#ff5f6d;--warning:#f5a623;--radius:10px;--radius-lg:14px;}
        *{box-sizing:border-box;margin:0;padding:0;}body{font-family:'Space Grotesk',sans-serif;background:var(--bg-primary);color:var(--text-primary);min-height:100vh;}
        nav{display:flex;align-items:center;justify-content:space-between;padding:0 2rem;height:64px;background:var(--bg-secondary);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:100;}
        .nav-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text-primary);}
        .nav-brand-name span:first-child{font-size:1rem;font-weight:700;display:block;line-height:1.2;}
        .nav-brand-name span:last-child{font-size:10px;color:var(--accent-bright);text-transform:uppercase;letter-spacing:.08em;display:block;}
        .nav-link{font-size:12px;color:var(--text-muted);text-decoration:none;padding:6px 14px;border:1px solid var(--border);border-radius:6px;transition:all .2s;}
        .nav-link:hover{color:var(--accent-bright);border-color:var(--accent-border);background:var(--accent-glow);}
        .container{max-width:860px;margin:0 auto;padding:3rem 2rem;}
        .hero{text-align:center;margin-bottom:2.5rem;}
        .hero-title{font-size:1.8rem;font-weight:700;margin-bottom:8px;}.hero-title span{color:var(--accent-bright);}
        .hero-sub{font-size:14px;color:var(--text-muted);}
        .config-warn{background:rgba(245,166,35,.08);border:1px solid rgba(245,166,35,.3);border-radius:var(--radius);padding:12px 16px;font-size:13px;color:var(--warning);margin-bottom:1.5rem;display:flex;align-items:center;gap:10px;}
        .config-warn a{color:var(--accent-bright);text-decoration:none;}
        .upload-box{border:2px dashed var(--border-strong);border-radius:var(--radius-lg);background:var(--bg-card);padding:3rem 2rem;text-align:center;cursor:pointer;transition:all .25s;}
        .upload-box.drag-over,.upload-box:hover{border-color:var(--accent);background:var(--accent-glow);}
        .upload-icon{font-size:2.8rem;margin-bottom:14px;opacity:.65;}
        .upload-text{font-size:14px;color:var(--text-secondary);}.upload-text strong{color:var(--accent-bright);}.upload-text strong.purple{color:#c084fc;}
        .upload-btn{display:inline-flex;align-items:center;gap:8px;margin-top:18px;padding:10px 24px;background:var(--accent);color:#fff;border:none;border-radius:var(--radius);font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .2s;box-shadow:0 4px 14px rgba(30,144,255,0.3);}
        .upload-btn:hover{background:var(--accent-bright);transform:translateY(-1px);}
        .progress-wrap{margin-top:16px;height:5px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
        .progress-bar{height:100%;background:linear-gradient(90deg,#0d4f9e,#1e90ff);border-radius:99px;transition:width .3s;}
        .upload-status{margin-top:10px;font-size:12px;color:var(--text-secondary);}
        .size-warn{margin-top:8px;font-size:11px;color:rgba(245,166,35,.7);}
        .result-section{margin-top:2rem;}.result-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;}
        .section-title{font-size:13px;font-weight:600;color:var(--text-secondary);text-transform:uppercase;letter-spacing:.07em;}
        .clear-btn{padding:5px 12px;border-radius:6px;border:1px solid var(--border);background:transparent;color:var(--text-muted);font-size:12px;cursor:pointer;font-family:inherit;transition:all .2s;}
        .clear-btn:hover{color:var(--danger);border-color:rgba(255,95,109,.3);}
        .result-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.2rem 1.5rem;margin-bottom:10px;display:flex;align-items:center;gap:14px;transition:border-color .2s;}
        .result-card:hover{border-color:var(--accent-border);}
        .result-thumb{width:44px;height:44px;border-radius:8px;background:var(--bg-secondary);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;overflow:hidden;}
        .result-thumb img{width:100%;height:100%;object-fit:cover;border-radius:8px;}
        .result-info{flex:1;min-width:0;}
        .result-name{font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .result-url{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--accent-bright);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:3px;}
        .badge{display:inline-block;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:600;text-transform:uppercase;margin-top:4px;}
        .badge-image{background:rgba(30,144,255,.15);color:#5bb4ff;}.badge-video{background:rgba(34,211,160,.12);color:#22d3a0;}.badge-audio{background:rgba(168,85,247,.15);color:#c084fc;}.badge-raw{background:rgba(245,166,35,.12);color:#f5a623;}
        .result-actions{display:flex;gap:6px;flex-shrink:0;}
        .icon-btn{width:32px;height:32px;border-radius:8px;border:1px solid var(--border);background:transparent;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;transition:all .2s;}
        .icon-btn:hover{background:var(--accent-glow);color:var(--accent-bright);border-color:var(--accent-border);}
        .icon-btn.danger:hover{background:rgba(255,95,109,.12);color:var(--danger);border-color:rgba(255,95,109,.3);}
        .toast{position:fixed;bottom:28px;right:24px;z-index:999;background:var(--bg-card);padding:10px 18px;border-radius:var(--radius);font-size:13px;font-weight:500;pointer-events:none;border:1px solid;}
        .player-bar{position:fixed;bottom:0;left:0;right:0;z-index:200;background:var(--bg-secondary);border-top:1px solid rgba(168,85,247,.3);padding:10px 2rem;display:flex;align-items:center;gap:20px;}
        .player-thumb{width:42px;height:42px;border-radius:8px;background:rgba(168,85,247,.2);border:1px solid rgba(168,85,247,.3);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
        .player-info{flex:0 0 200px;overflow:hidden;}
        .player-title{font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .player-format{font-size:11px;color:#a855f7;margin-top:2px;}
        .play-btn-player{width:38px;height:38px;background:var(--accent);border:none;border-radius:50%;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:15px;transition:all .2s;}
        .play-btn-player:hover{background:var(--accent-bright);}
        .player-seek-wrap{flex:1;display:flex;align-items:center;gap:10px;}
        .time-label{font-size:11px;color:var(--text-muted);font-family:'JetBrains Mono',monospace;min-width:36px;}
        .seek-bar,.vol-bar{-webkit-appearance:none;outline:none;border-radius:99px;background:rgba(255,255,255,.1);cursor:pointer;height:4px;}
        .seek-bar{flex:1;}.vol-bar{flex:1;}
        .seek-bar::-webkit-slider-thumb,.vol-bar::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;background:var(--accent);cursor:pointer;}
        .vol-wrap{display:flex;align-items:center;gap:8px;flex:0 0 130px;}
        .vol-icon{font-size:14px;color:var(--text-muted);}
        .player-close-btn{width:28px;height:28px;border-radius:6px;border:1px solid var(--border);background:transparent;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:12px;transition:all .2s;}
        .player-close-btn:hover{color:var(--danger);}
        .pb-space{height:80px;}
        ::-webkit-scrollbar{width:6px;}::-webkit-scrollbar-track{background:var(--bg-primary);}::-webkit-scrollbar-thumb{background:#1a3557;border-radius:99px;}
      `}</style>

      <nav>
        <a className="nav-brand" href="/"><div className="nav-brand-name"><span>CDN Yudaverse</span><span>GitHub Storage</span></div></a>
        <a className="nav-link" href="/configuration">⚙ Konfigurasi</a>
      </nav>

      <div className="container">
        <div className="hero">
          <div className="hero-title">Upload & Kelola <span>Media</span> Kamu</div>
          <div className="hero-sub">Gambar · Video · Audio · File — diakses via domain sendiri, disimpan di GitHub</div>
        </div>

        {!configOk && (
          <div className="config-warn">⚠ Konfigurasi GitHub belum lengkap. <a href="/configuration">Isi dulu di sini →</a></div>
        )}

        <div
          className={`upload-box${dragOver ? " drag-over" : ""}`}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files.length) handleFiles(Array.from(e.dataTransfer.files)); }}
          onClick={() => document.getElementById("file-input").click()}
        >
          <input type="file" id="file-input" multiple style={{ display: "none" }}
            accept="image/*,video/*,audio/*,.pdf,.zip,.txt,.doc,.docx,.xls,.xlsx,.ppt,.pptx"
            onChange={(e) => { if (e.target.files.length) handleFiles(Array.from(e.target.files)); e.target.value = ""; }}
          />
          <div className="upload-icon">📁</div>
          <div className="upload-text">Seret & lepas file, atau <strong>klik untuk memilih</strong></div>
          <div className="upload-text" style={{ marginTop: 6, fontSize: 12 }}>
            Gambar 🖼 · Video 🎬 · <strong className="purple">Musik 🎵</strong> · PDF · ZIP · dll
          </div>
          <button className="upload-btn" onClick={(e) => { e.stopPropagation(); document.getElementById("file-input").click(); }}>⬆ Pilih File</button>
          {hasBigFile && <div className="size-warn">⚠ File &gt;50MB mungkin gagal diupload ke GitHub.</div>}
          {uploading && (<><div className="progress-wrap"><div className="progress-bar" style={{ width: progress + "%" }} /></div><div className="upload-status">{statusMsg}</div></>)}
          {!uploading && statusMsg && <div className="upload-status">{statusMsg}</div>}
        </div>

        {uploadedFiles.length > 0 && (
          <div className="result-section">
            <div className="result-header">
              <div className="section-title">Hasil Upload</div>
              <button className="clear-btn" onClick={() => { setUploadedFiles([]); closePlayer(); }}>✕ Hapus Semua</button>
            </div>
            {uploadedFiles.map((f) => (
              <div className="result-card" key={f.id}>
                <div className="result-thumb">
                  {f.rtype === "image"
                    ? <img src={f.rawUrl} alt={f.name} onError={(e) => { e.target.style.display = "none"; }} />
                    : getTypeIcon(f.rtype)}
                </div>
                <div className="result-info">
                  <div className="result-name">{f.name}.{f.format}</div>
                  {/* Tampilkan URL vercel domain sendiri */}
                  <div className="result-url">{f.vercelUrl}</div>
                  <span className={`badge ${badgeClass[f.rtype]}`}>{f.rtype}</span>
                  <span style={{ fontSize: 10, color: "var(--text-muted)", marginLeft: 6 }}>{formatSize(f.size)}</span>
                </div>
                <div className="result-actions">
                  {f.rtype === "audio" && <button className="icon-btn" title="Putar" onClick={() => playAudio(f)}>▶</button>}
                  <button className="icon-btn" title="Salin URL" onClick={() => copyUrl(f.vercelUrl)}>⎘</button>
                  <button className="icon-btn" title="Buka" onClick={() => window.open(f.vercelUrl, "_blank")}>↗</button>
                  <button className="icon-btn danger" title="Hapus" onClick={() => removeFile(f.id)}>✕</button>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="pb-space" />
      </div>

      {currentTrack && (
        <div className="player-bar">
          <div className="player-thumb">🎵</div>
          <div className="player-info">
            <div className="player-title">{currentTrack.name}</div>
            <div className="player-format">{currentTrack.format?.toUpperCase()}</div>
          </div>
          <button className="play-btn-player" onClick={togglePlay}>{isPlaying ? "⏸" : "▶"}</button>
          <div className="player-seek-wrap">
            <span className="time-label">{timeNow}</span>
            <input type="range" className="seek-bar" min="0" max="100" step="0.1" value={seekVal} onChange={(e) => seekTo(e.target.value)} />
            <span className="time-label">{timeTotal}</span>
          </div>
          <div className="vol-wrap">
            <span className="vol-icon">🔊</span>
            <input type="range" className="vol-bar" min="0" max="100" value={volume} onChange={(e) => setVolume(Number(e.target.value))} />
          </div>
          <button className="player-close-btn" onClick={closePlayer}>✕</button>
        </div>
      )}

      {toast.show && (
        <div className="toast" style={{ borderColor: toast.error ? "var(--danger)" : "var(--success)", color: toast.error ? "var(--danger)" : "var(--success)" }}>
          {toast.msg}
        </div>
      )}
      <audio ref={audioRef} onTimeUpdate={handleTimeUpdate} onEnded={() => setIsPlaying(false)} onError={() => { setIsPlaying(false); showToast("⚠ Error memutar audio", true); }} />
    </>
  );
}
